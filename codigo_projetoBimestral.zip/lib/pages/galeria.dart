import 'package:flutter/material.dart';
import '../widgets/rodape.dart';


class GaleriaPage extends StatelessWidget {
  const GaleriaPage({super.key});

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    final List<String> imagens = [
      'https://picsum.photos/id/237/200/200',
      'https://picsum.photos/id/238/200/200',
      'https://picsum.photos/id/239/200/200',
      'https://picsum.photos/id/240/200/200',
      'https://picsum.photos/id/241/200/200',
      'https://picsum.photos/id/242/200/200',
      'https://picsum.photos/id/1015/400/400',
      'https://picsum.photos/id/1016/400/300',
      'https://picsum.photos/id/1018/400/250',
      'https://picsum.photos/id/1020/400/350',
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('Galeria')),
      body: Center(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            maxWidth: screenWidth > 600 ? 500 : double.infinity,
          ),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: GridView.count(
              crossAxisCount: 2,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
              children: imagens.map((url) {
                return GestureDetector(
                  onTap: () {
                    showDialog(
                      context: context,
                      builder: (_) => Dialog(
                        backgroundColor: Colors.transparent,
                        child: GestureDetector(
                          onTap: () {
                            Navigator.of(context).pop();
                          },
                          child: InteractiveViewer(
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(16),
                                image: DecorationImage(
                                  image: NetworkImage(url),
                                  fit: BoxFit.contain,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      image: DecorationImage(
                        image: NetworkImage(url),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),
        ),
      ),
      bottomNavigationBar: const CustomFooter(),

      
    );
  }
}

