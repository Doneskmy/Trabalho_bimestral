import 'package:flutter/material.dart';
import '../widgets/rodape.dart';

class ConfiguracoesPage extends StatefulWidget {
  const ConfiguracoesPage({super.key});

  @override
  State<ConfiguracoesPage> createState() => _ConfiguracoesPageState();
}

class _ConfiguracoesPageState extends State<ConfiguracoesPage> {
  bool modoEscuro = false;
  bool notificacoesAtivadas = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configurações')),
      body: ListView(
        children: [
          const ListTile(
            title: Text('Conta'),
            subtitle: Text('Gerencie sua conta'),
            leading: Icon(Icons.person),
            trailing: Icon(Icons.arrow_forward_ios),
          ),
          SwitchListTile(
            title: const Text('Modo escuro'),
            value: modoEscuro,
            onChanged: (bool valor) {
              setState(() {
                modoEscuro = valor;
              });
            },
            secondary: const Icon(Icons.dark_mode),
          ),
        SwitchListTile(
  title: const Text('Notificações'),
  value: notificacoesAtivadas,
  onChanged: (bool valor) {
    setState(() {
      notificacoesAtivadas = valor;
     
    });
    
    
  },
),

          const Divider(),
          const ListTile(
            title: Text('Sobre'),
            subtitle: Text('Versão 1.0.0'),
            leading: Icon(Icons.info),
          ),
        ],
      ),
      bottomNavigationBar: const CustomFooter(),
    );
  }
}
