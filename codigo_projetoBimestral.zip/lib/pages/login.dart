import 'package:flutter/material.dart';

class LoginFormScreen extends StatefulWidget {
  const LoginFormScreen({super.key});

  @override
  State<LoginFormScreen> createState() => _LoginFormScreenState();
}

class _LoginFormScreenState extends State<LoginFormScreen> {
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      appBar: AppBar(),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Center(
          child: ConstrainedBox(
            constraints: BoxConstraints(
              maxWidth: screenWidth > 600 ? 500 : double.infinity,
            ),
            child: Form(
              key: _formKey,
              child: Column(
                children: <Widget>[
                  const SizedBox(height: 16),
                  const Text(
                    'Entrar com:',
                    style: TextStyle(fontSize: 16),
                  ),
                  const SizedBox(height: 12),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      IconButton(
                        icon: const Icon(Icons.facebook, color: Colors.blue, size: 32),
                        onPressed: () {
                         
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.g_mobiledata, color: Colors.red, size: 32),
                        onPressed: () {
                        
                        },
                      ),
                      IconButton(
                        icon: const Icon(Icons.apple, color: Colors.black, size: 32),
                        onPressed: () {
                      
                        },
                      ),
                    ],
                  ),

                  const SizedBox(height: 32),
                  Row(
                    children: const [
                      Expanded(child: Divider()),
                      Padding(
                        padding: EdgeInsets.symmetric(horizontal: 8.0),
                        child: Text('ou',
                        style: TextStyle(color: Color(0xFF595959), fontSize: 20)),
                      ),
                      Expanded(child: Divider()),
                    ],
                  ),
                  const SizedBox(height: 32),

                  TextFormField(
                    decoration: const InputDecoration(
                      labelText: 'E-mail',
                      hintText: 'Entre com seu email',
                    ),
                    validator: (String? value) {
                      if (value == null || value.isEmpty) {
                        return 'Por favor entre com algum texto';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 16),
                  TextFormField(
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Senha',
                      hintText: 'Digite sua senha',
                    ),
                    validator: (String? value) {
                      if (value == null || value.isEmpty) {
                        return 'Digite a senha';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 24),

                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 16.0),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        minimumSize: const Size(double.infinity, 50),
                      ),
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(content: Text('Processando dados...')),
                          );
                        }
                      },
                      child: const Text(
                        'Enviar',
                        style: TextStyle(fontSize: 16),
                      ),
                    ),
                  ),
                  TextButton(onPressed: () {}, 
                      child: const Text(
                        'Esqueci a minha senha',
                        style: TextStyle(color: Colors.red, fontSize: 16),
                      ),
                  ),
                  
                  const SizedBox(height: 16),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, '/galeria');
                    },
                    child: const Text('Ver Galeria'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
