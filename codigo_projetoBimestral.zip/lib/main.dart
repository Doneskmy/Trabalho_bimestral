import 'package:flutter/material.dart';
import 'package:projeto/pages/configuracoes.dart';
import 'pages/galeria.dart';
import 'pages/login.dart'; 
import 'pages/boasvindas.dart';
import 'theme/tema.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: appTheme,
      title: 'App Art Jousrnal',
      initialRoute: '/',
      routes: {
        '/': (context) => const BoasVindasPage(),
        '/login': (context) => const LoginFormScreen(),
        '/galeria': (context) => const GaleriaPage(),
        '/configuracoes': (context) => ConfiguracoesPage()
      },
    );
  }
}
